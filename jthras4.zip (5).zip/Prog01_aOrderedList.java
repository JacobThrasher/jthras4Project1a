import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * This is the main class for managing an ordered list of Car objects.
 * It reads from an input file to add or delete Car objects based on the instructions provided in the file,
 * then writes the final state of the ordered list to an output file.
 * CSC 1351 Programming Project No 7
 * Section 3
 *
 * @author jthras4
 * @since 16/03/2024
 */
public class Prog01_aOrderedList {
    public static void main(String[] args) {
        try {
            Prog01_aOrderedList prog01AOrderedList = new Prog01_aOrderedList();

            aOrderedList orderedList = new aOrderedList(); // Initialize an ordered list to store Car objects.

            // Get a scanner object for reading the input file.
            Scanner inputScanner = prog01AOrderedList.GetInputFile("Enter input filename: ");
            while (inputScanner.hasNextLine()) {
                String line = inputScanner.nextLine();
                String[] splittedData = line.split(",");
                // Add a new Car to the ordered list if the line starts with 'A'.
                if (splittedData[0].equalsIgnoreCase("A")) {
                    String make = splittedData[1];
                    int year = Integer.parseInt(splittedData[2]);
                    int price = Integer.parseInt(splittedData[3]);
                    Car car = new Car(make, year, price);
                    orderedList.add(car);
                }
                // Remove a Car from the list based on the provided index or make and year if the line starts with 'D'.
                else if (splittedData[0].equalsIgnoreCase("D")) {
                    try{
                        int index = Integer.parseInt(splittedData[1]);
                        orderedList.remove(index);
                    }catch (NumberFormatException e){
                        String make = splittedData[1];
                        int year =  Integer.parseInt(splittedData[2]);
                        orderedList.remove(make, year);
                    }

                }
            }
            inputScanner.close();

            // Get a PrintWriter object for writing to the output file.
            PrintWriter outputPrintWriter = prog01AOrderedList.GetOutputFile("Enter output filename: ");
            outputPrintWriter.println("Number of cars: " + orderedList.size());
            while (orderedList.hasNext()) {
                outputPrintWriter.println();

                Car car = (Car) orderedList.next();

                // Format and print the details of each Car object to the output file.
                outputPrintWriter.printf("%-10s%10s\n", "Make:", car.getMake());
                outputPrintWriter.printf("%-10s%10s\n", "Year:", car.getYear());
                outputPrintWriter.printf("%-10s%10s\n", "Price:", String.format("$%,d", car.getPrice()));
            }
            outputPrintWriter.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
        }
    }

    /**
     * Ask from the user for the input file path, and returns a Scanner to read the file.
     *
     * @param UserPrompt The prompt message to be displayed to the user.
     * @return A Scanner object for reading the input file.
     * @throws FileNotFoundException If the file does not exist.
     */
    public Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print(UserPrompt);
            String inputFileName = scanner.nextLine();
            File file = new File(inputFileName);
            if (file.exists()) {
                return new Scanner(file);
            } else {
                System.out.print("File specified <" + inputFileName + "> does not exist. Would you like to continue? <Y/N> ");
                String answer = scanner.nextLine();
                if (answer.equalsIgnoreCase("Y")) {
                    continue;
                }
                scanner.close();
                throw new FileNotFoundException();
            }
        }
    }

    /**
     * Prompts the user for the output file path and returns a PrintWriter to write to the file.
     *
     * @param UserPrompt The prompt message to be displayed to the user.
     * @return A PrintWriter object for writing to the output file.
     * @throws FileNotFoundException If the file cannot be opened for writing.
     */
    public PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print(UserPrompt);
            String outputFileName = scanner.nextLine();
            try {
                return new PrintWriter(outputFileName);
            } catch (FileNotFoundException e) {
                System.out.print("File specified <" + outputFileName + "> cannot open for writing. Would you like to continue? <Y/N> ");
                String answer = scanner.nextLine();
                if (answer.equalsIgnoreCase("Y")) {
                    continue;
                }
                scanner.close();
                throw new FileNotFoundException();
            }
        }
    }
}

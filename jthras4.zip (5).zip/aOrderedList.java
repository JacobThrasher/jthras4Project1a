import java.util.Arrays;


/**
 * This class is for a self-sorting list designed to hold and organize Comparable objects,
 * such as Car objects. It supports adding, removing, and iterating over items,
 * automatically resizing as needed.
 *
 * CSC 1351 Programming Project No 7
 * Section 3
 *
 * @author jthras4
 * @since 16/03/2024
 */
public class aOrderedList {
    private final int SIZEINCREMENTS = 20; // Specifies the increment size for the array holding the list elements.
    private Comparable[] oList; // Array to store the elements of the ordered list.
    private int listSize; // Current allocated size of the oList array.
    private int numObjects;  // Number of objects currently in the list.
    private int curr; // Current position of the iterator.

    /**
     * Constructs an empty ordered list with an initial capacity defined by SIZEINCREMENTS.
     */
    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Car[SIZEINCREMENTS];
    }

    /**
     * Adds a new object to the list.
     * If the list is full the list is expanded by SIZEINCREMENTS
     *
     * @param newObject The Comparable object to be added to the list.
     */
    public void add(Comparable newObject) {

        if (numObjects == listSize) {
            listSize += SIZEINCREMENTS;
            oList = Arrays.copyOf(oList, listSize);
        }

        int correctPosition;
        for (correctPosition = 0; correctPosition < numObjects; correctPosition++) {
            if (newObject.compareTo(oList[correctPosition]) < 0)
                break;
        }

        for (int i = numObjects; i > correctPosition; i--) {
            oList[i] = oList[i - 1];
        }

        oList[correctPosition] = newObject;
        numObjects++;
    }

    /**
     * Returns a string representation of the list, showing all the elements in their current order.
     *
     * @return A string representation of the list.
     */
    public String toString() {
        StringBuilder outputStringBuilder = new StringBuilder("[");
        for (int i = 0; i < numObjects; i++) {
            outputStringBuilder.append(oList[i].toString());
            if (i != numObjects - 1) {
                outputStringBuilder.append("; ");
            }
        }
        outputStringBuilder.append("]");
        return outputStringBuilder.toString();
    }

    /**
     * Returns the number of elements in the list.
     *
     * @return The size of the list as an integer.
     */
    public int size() {
        return numObjects;
    }

    /**
     * Retrieves the element at the specified index.
     *
     * @param index The index of the element to retrieve.
     * @return The element at the specified index.
     * @throws IndexOutOfBoundsException if the index is out of range.
     */
    public Comparable get(int index) {
        if (index < 0 || index >= numObjects)
            throw new IndexOutOfBoundsException();
        return oList[index];
    }

    /**
     * Checks if the list is empty.
     *
     * @return true if the list contains no elements; false otherwise.
     */
    public boolean isEmpty() {
        return numObjects == 0;
    }


    /**
     * Removes the element at the specified index from the list.
     *
     * @param index The index of the element to remove.
     * @throws IndexOutOfBoundsException if the index is out of range.
     */
    public void remove(int index) {
        if (index < 0 || index >= numObjects)
            throw new IndexOutOfBoundsException();

        for (int i = index; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
        oList[numObjects - 1] = null;
        numObjects--;
    }

    /**
     * Resets the iterator to the start of the list.
     */

    public void reset() {
        curr = 0;
    }


    /**
     * Returns the next element in the list during iteration.
     *
     * @return The next element in the list.
     * @throws IndexOutOfBoundsException if there is no next element.
     */
    public Comparable next() {
        if (!hasNext()) {
            throw new IndexOutOfBoundsException();
        }
        return oList[curr++];
    }


    /**
     * Checks if there is a next element in the list during iteration.
     *
     * @return true if there is a next element; false otherwise.
     */
    public boolean hasNext() {
        return curr < numObjects;
    }


    /**
     * Removes the current element during iteration.
     */
    public void remove() {
        remove(curr - 1);
        curr--;
    }

    /**
     * Removes a Car object from the list based on a specific make and year.
     *
     * @param make The make of the Car to be removed.
     * @param year The year of the Car to be removed.
     */
    public void remove(String make, int year) {
        reset();
        while (hasNext()) {
            Car car = (Car) next();
            if (car.getMake().equalsIgnoreCase(make) && car.getYear() == year) {
                remove();
                reset();
                return;
            }
        }
        reset();
    }


}
